// You can import Ionicons from @expo/vector-icons if you use Expo or
// react-native-vector-icons/Ionicons otherwise.
import * as React from 'react';
import { Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { WebView } from 'react-native';

function HomeView() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Home!</Text>
    </View>
  );
}

function DonateView() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Settings!</Text>
    </View>
  );
}

function AppsView() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Website!</Text>
    </View>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'Home') {
              iconName = focused ? 'home' : 'home-outline';
            }
            else if (route.name === 'Docs') {
              iconName = focused ? 'document-text' : 'document-text-outline';
            }
            else if (route.name === 'Guides') {
              iconName = focused ? 'documents' : 'documents-outline';
            }
            else if (route.name === 'Apps') {
              iconName = focused ? 'apps' : 'apps-outline';
            }
            else if (route.name === 'Contact') {
              iconName = focused ? 'mail' : 'mail-outline';
            }
            else if (route.name === 'Donate') {
              iconName = focused ? 'cog' : 'cog-outline';
            }
            else if (route.name === 'Terms') {
              iconName = focused ? 'apps' : 'apps-outline';
            }
            else if (route.name === 'Privacy') {
              iconName = focused ? 'apps' : 'apps-outline';
            }
            else if (route.name === 'Search') {
              iconName = focused ? 'search' : 'search-outline';
            }

            // You can return any component that you like here!
            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: '#147efb',
          tabBarInactiveTintColor: 'gray',
        })}>
        <Tab.Screen name="Home" component={HomeView} />
        <Tab.Screen name="Docs" component={AppsView} />
        <Tab.Screen name="Guides" component={AppsView} />
        <Tab.Screen name="Apps" component={AppsView} />
        <Tab.Screen name="Contact" component={AppsView} />
        <Tab.Screen name="Donate" component={DonateView} />
        <Tab.Screen name="Terms" component={AppsView} />
        <Tab.Screen name="Privacy" component={AppsView} />
        <Tab.Screen name="Search" component={AppsView} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
